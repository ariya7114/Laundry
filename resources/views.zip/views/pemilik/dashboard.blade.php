@extends('layouts.app')
@section('title', 'Dashboard Pemilik')

@section('content')
<div class="space-y-6">
    <h1 class="text-2xl font-bold">Halo, Pemilik {{ Auth::user()->name }}</h1>

    {{-- Statistik Utama --}}
    <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        <div class="bg-white p-6 rounded-xl shadow">
            <h2 class="text-lg font-semibold mb-2">Statistik Pendapatan</h2>
            <p class="text-2xl font-bold text-green-600">Rp12.500.000</p>
            <a href="{{ route('pemilik.pendapatan') }}" class="text-blue-500 hover:underline">Lihat detail »</a>
        </div>
        <div class="bg-white p-6 rounded-xl shadow">
            <h2 class="text-lg font-semibold mb-2">Laporan Harian</h2>
            <p class="text-gray-600">Tersedia laporan harian, mingguan & bulanan</p>
            <a href="#" class="text-blue-500 hover:underline">Download laporan »</a>
        </div>
        <div class="bg-white p-6 rounded-xl shadow">
            <h2 class="text-lg font-semibold mb-2">Jumlah Kasir</h2>
            <p class="text-2xl font-bold text-indigo-600">5</p>
        </div>
        <div class="bg-white p-6 rounded-xl shadow">
            <h2 class="text-lg font-semibold mb-2">Jumlah Pelanggan</h2>
            <p class="text-2xl font-bold text-orange-500">120</p>
        </div>
        <div class="bg-white p-6 rounded-xl shadow">
            <h2 class="text-lg font-semibold mb-2">Total Layanan</h2>
            <p class="text-2xl font-bold text-purple-500">3 Jenis (Cuci, Gosok, Cuci-Gosok)</p>
        </div>
    </div>
</div>
@endsection
