@extends('layouts.app')

@section('title', 'Pendapatan Pemilik')

@section('content')
<div class="space-y-6">
    <h1 class="text-2xl font-bold text-gray-800">Grafik Pendapatan Harian</h1>

    <div class="bg-white p-6 rounded-xl shadow">
        <canvas id="pendapatanChart" height="120"></canvas>
    </div>
</div>
@endsection

@section('scripts')
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const ctx = document.getElementById('pendapatanChart').getContext('2d');

    const chart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: {!! json_encode($data['labels']) !!},
            datasets: [{
                label: 'Pendapatan Harian',
                data: {!! json_encode($data['values']) !!},
                backgroundColor: 'rgba(99, 102, 241, 0.7)',
                borderColor: 'rgba(99, 102, 241, 1)',
                borderWidth: 1,
                borderRadius: 6,
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return 'Rp ' + value.toLocaleString('id-ID');
                        }
                    }
                }
            }
        }
    });
</script>
@endsection
