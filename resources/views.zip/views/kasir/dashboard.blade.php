{{-- resources/views/dashboard/kasir.blade.php --}}
@extends('layouts.app')

@section('content')
<div class="container">
    <h1 class="mb-4">Dashboard Kasir</h1>

    <div class="row">
        <div class="col-md-6 mb-3">
            <a href="{{ route('kasir.transaksi.form') }}" class="btn btn-primary btn-lg btn-block">➕ Input Transaksi</a>
        </div>
        <div class="col-md-6 mb-3">
            <a href="{{ route('kasir.riwayat') }}" class="btn btn-secondary btn-lg btn-block">📄 Riwayat Transaksi</a>
        </div>
    </div>
</div>
@endsection
