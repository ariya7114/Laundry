{{-- resources/views/kasir/riwayat-transaksi.blade.php --}}
@extends('layouts.app')

@section('content')
<div class="container">
    <h2 class="mb-4">Riwayat Transaksi</h2>

    @if($transaksis->isEmpty())
        <p>Tidak ada transaksi ditemukan.</p>
    @else
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Jenis Jasa</th>
                    <th>Berat (kg)</th>
                    <th>Total Harga (Rp)</th>
                    <th>Metode</th>
                    <th>Status</th>
                    <th>Tanggal</th>
                </tr>
            </thead>
            <tbody>
                @foreach($transaksis as $trx)
                <tr>
                    <td>{{ $trx->jenis_jasa }}</td>
                    <td>{{ $trx->berat }}</td>
                    <td>{{ number_format($trx->total_harga, 0, ',', '.') }}</td>
                    <td>{{ ucfirst($trx->metode_pembayaran) }}</td>
                    <td>{{ $trx->status }}</td>
                    <td>{{ $trx->created_at->format('d-m-Y H:i') }}</td>
                </tr>
                @endforeach
            </tbody>
        </table>
    @endif
</div>
@endsection
