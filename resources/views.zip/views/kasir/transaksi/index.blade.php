{{-- resources/views/kasir/index.blade.php --}}
@extends('layouts.app')

@section('content')
<div class="container">
    <h2 class="mb-4">Form Input Transaksi</h2>

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif

    <form method="POST" action="{{ route('kasir.transaksi.simpan') }}">
        @csrf

        <div class="form-group">
            <label for="jenis_jasa">Jenis Jasa</label>
            <select name="jenis_jasa" class="form-control" required>
                <option value="">-- Pilih Jasa --</option>
                <option value="cuci">Cuci</option>
                <option value="gosok">Gosok</option>
                <option value="cuci-gosok">Cuci & Gosok</option>
            </select>
        </div>

        <div class="form-group mt-3">
            <label for="berat">Berat (kg)</label>
            <input type="number" step="0.1" name="berat" class="form-control" required>
        </div>

        <div class="form-group mt-3">
            <label for="total_harga">Total Harga (Rp)</label>
            <input type="number" name="total_harga" class="form-control" required>
        </div>

        <div class="form-group mt-3">
            <label for="metode_pembayaran">Metode Pembayaran</label>
            <select name="metode_pembayaran" class="form-control" required>
                <option value="cash">Cash</option>
                <option value="transfer">Transfer</option>
            </select>
        </div>

        <button type="submit" class="btn btn-success mt-4">Simpan Transaksi</button>
    </form>
</div>
@endsection
