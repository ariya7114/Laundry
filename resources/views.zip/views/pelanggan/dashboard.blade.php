@extends('layouts.app')
@section('title', 'Dashboard Pelanggan')
@section('content')
<div class="space-y-6">
    <h1 class="text-2xl font-bold">Selamat datang, {{ Auth::user()->name }}</h1>

    <div class="bg-white p-6 rounded-xl shadow space-y-4">
        <div>
            <h2 class="font-semibold text-lg mb-2">Status Cucian Anda</h2>
            <ul class="list-disc pl-5">
                <li>Order #12345 - <span class="text-blue-600 font-medium">Sedang Diproses</span></li>
                <li>Order #12344 - <span class="text-green-600 font-medium">Selesai & Diantar</span></li>
            </ul>
        </div>

        <div>
            <h2 class="font-semibold text-lg mb-2">Upload Bukti Pembayaran</h2>
            <form>
                <input type="file" class="form-input mb-2">
                <button class="btn btn-success hover:bg-green-700 transition-all">Upload</button>
            </form>
        </div>
    </div>
</div>
@endsection
