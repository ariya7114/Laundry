@extends('layouts.app')

@section('title', 'Edit Profil')

@section('content')
<div class="container mx-auto max-w-2xl mt-10 bg-white p-8 shadow rounded-lg">
    <h2 class="text-2xl font-bold mb-6 border-b pb-2">Edit Profil</h2>

    @if (session('status') === 'profile-updated')
        <div class="alert alert-success mb-4">
            Profil berhasil diperbarui.
        </div>
    @endif

    <form method="POST" action="{{ route('profile.update') }}">
        @csrf
        @method('PATCH')

        <div class="mb-4">
            <label for="name" class="form-label font-medium">Nama</label>
            <input type="text" id="name" name="name" class="form-control @error('name') is-invalid @enderror"
                   value="{{ old('name', $user->name) }}" required>
            @error('name')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="mb-4">
            <label for="email" class="form-label font-medium">Email</label>
            <input type="email" id="email" name="email" class="form-control @error('email') is-invalid @enderror"
                   value="{{ old('email', $user->email) }}" required>
            @error('email')
                <div class="invalid-feedback">{{ $message }}</div>
            @enderror
        </div>

        <div class="flex justify-between">
            <button type="submit" class="btn btn-primary">
                Simpan Perubahan
            </button>

            <button type="button" onclick="document.getElementById('delete-modal').showModal()" class="btn btn-danger">
                Hapus Akun
            </button>
        </div>
    </form>

    {{-- Modal Konfirmasi Hapus Akun --}}
    <dialog id="delete-modal" class="modal">
        <form method="POST" action="{{ route('profile.destroy') }}" class="modal-box">
            @csrf
            @method('DELETE')

            <h3 class="font-bold text-lg mb-4">Konfirmasi Hapus Akun</h3>
            <p class="mb-4 text-sm text-gray-600">Masukkan password Anda untuk menghapus akun secara permanen.</p>

            <input type="password" name="password" class="form-control @error('password', 'userDeletion') is-invalid @enderror"
                   placeholder="Password" required>
            @error('password', 'userDeletion')
                <div class="invalid-feedback mt-1">{{ $message }}</div>
            @enderror

            <div class="modal-action mt-4">
                <button type="submit" class="btn btn-danger">Hapus</button>
                <button type="button" onclick="document.getElementById('delete-modal').close()" class="btn">Batal</button>
            </div>
        </form>
    </dialog>
</div>
@endsection
