@extends('layouts.app')

@section('title', 'Dashboard Admin')

@section('content')
<div class="mb-6">
    <h1 class="text-2xl font-bold text-gray-800">Dashboard Admin</h1>
    <p class="text-gray-600">Halo, <span class="font-semibold text-indigo-600">{{ ucfirst(Auth::user()->name) }}</span>! Anda login sebagai <strong>Admin</strong>.</p>
</div>

<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-6">
    <div class="bg-white shadow-md rounded-xl p-6 hover:shadow-xl transition-all">
        <h2 class="text-sm text-gray-500 mb-2">Pengguna Terdaftar</h2>
        <p class="text-3xl font-bold text-indigo-600">150</p>
    </div>
    <div class="bg-white shadow-md rounded-xl p-6 hover:shadow-xl transition-all">
        <h2 class="text-sm text-gray-500 mb-2">Transaksi Hari Ini</h2>
        <p class="text-3xl font-bold text-green-600">27</p>
    </div>
    <div class="bg-white shadow-md rounded-xl p-6 hover:shadow-xl transition-all">
        <h2 class="text-sm text-gray-500 mb-2">Pendapatan</h2>
        <p class="text-3xl font-bold text-emerald-600">Rp 2.500.000</p>
    </div>
</div>

<div class="bg-white shadow-sm rounded-xl p-4 mt-4 text-sm text-gray-500 italic">
    Terakhir login: {{ \Carbon\Carbon::parse(Auth::user()->last_login_at)->translatedFormat('d F Y, H:i') }}
</div>
@endsection
