<?php

namespace App\Http\Controllers;

use App\Models\Transaksi;
use App\Models\Pekerja;
use Illuminate\Http\Request;

class KasirController extends Controller
{
    // Tampilkan halaman dashboard kasir
    public function index()
    {
        $totalTransaksi = Transaksi::count();
        $totalPendapatan = Transaksi::sum('total_harga');

        return view('kasir.dashboard', compact('totalTransaksi', 'totalPendapatan'));
    }

    // Tampilkan daftar semua pekerja
    public function pekerja()
    {
        $pekerjas = Pekerja::all();
        return view('kasir.pekerja', compact('pekerjas'));
    }

    // Tampilkan daftar semua transaksi
    public function transaksi()
    {
        $transaksis = Transaksi::latest()->get();
        return view('kasir.transaksi', compact('transaksis'));
    }

    // Simpan transaksi baru (umum)
    public function simpanTransaksi(Request $request)
    {
        $request->validate([
            'nama_pelanggan' => 'required|string|max:100',
            'total_bayar' => 'required|numeric|min:0',
            'layanan' => 'required|string',
            'pekerja_id' => 'required|exists:pekerjas,id',
        ]);

        Transaksi::create([
            'nama_pelanggan' => $request->nama_pelanggan,
            'total_bayar' => $request->total_bayar,
            'layanan' => $request->layanan,
            'pekerja_id' => $request->pekerja_id,
        ]);

        return redirect()->route('kasir.transaksi')->with('success', 'Transaksi berhasil disimpan.');
    }

    // Hapus transaksi berdasarkan ID
    public function hapusTransaksi($id)
    {
        $transaksi = Transaksi::findOrFail($id);
        $transaksi->delete();

        return redirect()->back()->with('success', 'Transaksi berhasil dihapus.');
    }
}
