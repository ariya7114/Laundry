<?php

namespace App\Http\Controllers\Kasir;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class RiwayatController extends Controller
{
    public function index()
    {
        // Ambil data riwayat dari database, misalnya:
        // $riwayat = Transaksi::where('kasir_id', auth()->id())->latest()->get();

        return view('kasir.riwayat.index'); // Buat file Blade ini
    }

}
